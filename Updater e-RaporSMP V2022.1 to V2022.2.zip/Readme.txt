=============================
Aplikasi e-Rapor SMP 2013 V.2022.2
=============================

e-Rapor SMP 2013 v.2022.2 adalah aplikasi/perangkat lunak berbasis web yang berfungsi 
untuk menyusun laporan capaian kompetensi peserta didik (Rapor) 
pada satuan pendidikan di tingkat Sekolah Menengah Pertama (SMP)
Aplikasi e-Rapor SMP dikembangkan dengan mengacu pada kaidah-kaidah 
sistem penilaian sebagaimana tertuang dalam Pandauan Pembelajaran dan Asesmen Tahun 2022 
dan dapat diimplementasikan pada satuan pendidikan pelaksana Kurikulum 2013.

Secara teknis Aplikasi e-Rapor SMP didesain terintegrasi dengan Aplikasi Dapodik yang dikeluarkan 
oleh Sekretariat Direktorat Jenderal Pendidikan Dasar dan Menengah (Setditjen Dikdasmen). 
Aplikasi e-Rapor SMP akan terus dikembangkan dan dilakukan penyesuian sejalan dengan perkembangan Aplikasi Dapodik.
Aplikasi e-Rapor SMP dikembangkan oleh Tim Pengembang eRapor SMP.

Aplikasi ini tentu masih jauh dari sempurna. Untuk itu, demi kesempurnaan aplikasi ini, Masukkan dari stakeholder sangat kami perlukan. 
Jika ada masukan terkait aplikasi ini, silahkan menghubungi kami melalui kontak tim pengembang atau tim suport sebagaimana ditampilkan dalam aplikasi ini.


Versi Aplikasi: V.2022.2

tim pengembang


## Dilarang memodifikasi dan memperjual-belikan aplikasi ini tanpa seijin Pengembang ##
@2023